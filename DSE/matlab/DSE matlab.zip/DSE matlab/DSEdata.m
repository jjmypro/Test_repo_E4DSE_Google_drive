clear;
clc;
%% data indhentning fra dataark optaget af analog discovery
%data 1  = 5V   0.3A
%data 2  = 7.5V 1A
%data 3  = 10V  1.2A
%code for names 
% UT = uden tid
% USN = uden sample number
data1 = csvread('Data1mlmtmsn.csv');
data1_utusn = csvread('Data1mlutusn.csv');
data2 = csvread('7.5Volt_1Amps_with_lid_with_time_and_sample_number.csv');
data2_utusn = csvread('7.5Volt_1Amps_with_lid_without_time_and_sample_number.csv');
data3 = csvread('10Volt_1.2Amps_with_lid.csv');
data3_utusn = csvread('10Volt_1.2Amps_with_lid_without_time_and_sample_number.csv');
datatotal = (data1_utusn + data2_utusn + data3_utusn)/3;
%%plots af datas�ts
% ----------- 1. datas�t -------------
figure('name', 'datas�t for f�rste m�ling m. 5V 0.3A')
subplot(1,2,1)
plot(data1)
xlim([0 7000])
title('1. datas�t med 5V 0.3A med tid og sample nummer'), grid minor
subplot(1,2,2)
plot(data1_utusn)
xlim([0 7000])
title('1. data med 5V 0.3A uden tid og sample nummer'), grid minor
% ----------- 2. datas�t -------------
figure('name','datas�t for anden m�ling m. 7.5V 1A')
subplot(1,2,1)
plot(data2)
xlim([0 7000])
title('2. datas�t med 7.5V 1A med tid og sample nummer'), grid minor
subplot(1,2,2)
plot(data2_utusn)
xlim([0 7000])
title('2. datas�t med 7.5V 1A uden tid og sample nummer'), grid minor
% ----------- 3. datas�t -------------
figure('name','datas�t for 3. m�ling m. 10V 1.2A')
subplot(1,2,1)
plot(data3)
xlim([0 7000])
title('3. datas�t med 10V 1.2A med tid og sample nummer'), grid minor
subplot(1,2,2)
plot(data3_utusn)
xlim([0 7000])
title('3.datas�t med 10V 1.2A uden tid og sample nummer'), grid minor
% ----------- gennemsnit af alle 3 datas�t -------------
figure('name','total gennemsnit at datas�ts')
plot(datatotal)
xlim([0 7000])
title('total gennemsnit af datas�t'), grid minor

%%udregninger
begyndelsesvardi = 234; %afl�st p� totalgraf
steady_state = 405.66;  %afl�st p� totalgraf
t = (steady_state - begyndelsesvardi)*0.632 + begyndelsesvardi
tau = 1926;
K = 1.74;
TF = K/(tau*s+1);
figure('name', 'overf�ringsfunktion')
plot(TF)
title('overf�ringsfunktion'), grid minor
